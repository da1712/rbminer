#!/usr/bin/env bash

cd "$(dirname "$0")"

echo "adios" > stopp.txt
