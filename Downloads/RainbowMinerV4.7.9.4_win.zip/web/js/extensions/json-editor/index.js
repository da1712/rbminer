/**
 * @file A simple JSON viewer and editor
 * @author yuhui06
 * @date 2018/5/25
 */

require('./jquery.json-viewer.css');

__inline('./jquery.json-viewer.js');
__inline('./jquery.json-editor.js');