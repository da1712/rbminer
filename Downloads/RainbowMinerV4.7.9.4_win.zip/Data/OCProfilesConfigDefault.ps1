﻿[PSCustomObject]@{
    'Profile0-GTX1060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-GTX1060' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-GTX1060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-GTX1060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "150"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-GTX1060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-GTX1060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "250"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-GTX1060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-GTX1060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-GTX10603GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-GTX10603GB' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-GTX10603GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-GTX10603GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "150"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-GTX10603GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-GTX10603GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "250"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-GTX10603GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-GTX10603GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-GTX10606GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-GTX10606GB' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-GTX10606GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-GTX10606GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "150"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-GTX10606GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-GTX10606GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "250"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-GTX10606GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-GTX10606GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-GTX1070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-GTX1070' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-GTX1070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-GTX1070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "200"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-GTX1070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-GTX1070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "350"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-GTX1070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-GTX1070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-GTX1070TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-GTX1070TI' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-GTX1070TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-GTX1070TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "200"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-GTX1070TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-GTX1070TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "350"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-GTX1070TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-GTX1070TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-GTX1080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-GTX1080' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-GTX1080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-GTX1080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "200"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-GTX1080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-GTX1080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "350"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-GTX1080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-GTX1080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-GTX1080TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-GTX1080TI' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-GTX1080TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-GTX1080TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "200"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-GTX1080TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-GTX1080TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "350"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-GTX1080TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-GTX1080TI' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-P104100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-P104100' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-P104100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-P104100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "200"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-P104100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-P104100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "350"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-P104100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-P104100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-P1041004GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-P1041004GB' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-P1041004GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-P1041004GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "200"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-P1041004GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-P1041004GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "350"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-P1041004GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-P1041004GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-P1041008GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-P1041008GB' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-P1041008GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-P1041008GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "200"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-P1041008GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-P1041008GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "350"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-P1041008GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-P1041008GB' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-P106100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-P106100' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-P106100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-P106100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "150"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-P106100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-P106100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "250"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-P106100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-P106100' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-RTX2060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-RTX2060' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-RTX2060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-RTX2060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "150"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-RTX2060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-RTX2060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "250"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-RTX2060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-RTX2060' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "300"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-RTX2070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-RTX2070' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-RTX2070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-RTX2070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "200"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-RTX2070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-RTX2070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "350"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-RTX2070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-RTX2070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-RTX2080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-RTX2080' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-RTX2080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-RTX2080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "200"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-RTX2080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-RTX2080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "350"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-RTX2080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-RTX2080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "400"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-RTX3070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-RTX3070' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-RTX3070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "1000"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-RTX3070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-RTX3070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-1000"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-RTX3070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "875"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-RTX3070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "1000"
        CoreClockBoost = "-500"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-RTX3070' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "1000"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-RTX3080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-RTX3080' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-RTX3080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "1000"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-RTX3080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-RTX3080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-1000"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-RTX3080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "875"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-RTX3080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "1000"
        CoreClockBoost = "-500"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-RTX3080' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "1000"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile0-RTX3090' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-500"
        CoreClockBoost = "0"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile1-RTX3090' = [PSCustomObject]@{
        PowerLimit = 0
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "*"
        CoreClockBoost = "*"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile2-RTX3090' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "1000"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile3-RTX3090' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "500"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile4-RTX3090' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "-1000"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile5-RTX3090' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "875"
        CoreClockBoost = "100"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile6-RTX3090' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "1000"
        CoreClockBoost = "-500"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
    'Profile7-RTX3090' = [PSCustomObject]@{
        PowerLimit = 80
        ThermalLimit = 0
        PriorizeThermalLimit = 0
        MemoryClockBoost = "1000"
        CoreClockBoost = "50"
        LockVoltagePoint = "*"
        LockMemoryClock = "*"
        LockCoreClock = "*"
    }
}
