#!/usr/bin/env bash

cd "$(dirname "$0")"

rbmtail ./Logs rbm
