#!/usr/bin/env bash

cd "$(dirname "$0")"

nohup ./start.sh >/dev/null 2>&1 
