#!/usr/bin/env bash

cd "$(dirname "$0")"

screen -S RainbowMiner -d -m ./start.sh
